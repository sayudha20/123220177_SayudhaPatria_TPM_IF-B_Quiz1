import 'package:flutter/material.dart';
import 'dart:math';

class MenuKubus extends StatefulWidget {
  @override
  _MenuKubusState createState() => _MenuKubusState();
}

class _MenuKubusState extends State<MenuKubus> {
  final _formKey = GlobalKey<FormState>();
  double? _sisi;
  double? _volume, _keliling;

  void _hitung() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      setState(() {
        _volume = (pow(_sisi!, 3) as double);
        _keliling = 12 * _sisi!;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menu Kubus')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Panjang sisi (s) [cm]',
                        ),
                        keyboardType: TextInputType.number,
                        onSaved: (value) => _sisi = double.tryParse(value!),
                        validator: (value) {
                          if (value!.isEmpty) return 'Input tidak boleh kosong';
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: _hitung,
                child: Text('Hitung', style: TextStyle(fontSize: 18)),
              ),
              if (_volume != null && _keliling != null) ...[
                Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Text(
                          'Volume Kubus: ${_volume!.toStringAsFixed(2)} m³',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Keliling Kubus: ${_keliling!.toStringAsFixed(2)} cm',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
