import 'package:flutter/material.dart';
import 'dart:math';

class MenuPenghitungHari extends StatefulWidget {
  @override
  _MenuPenghitungHariState createState() => _MenuPenghitungHariState();
}

class _MenuPenghitungHariState extends State<MenuPenghitungHari> {
  final _formKey = GlobalKey<FormState>();
  int? _hari;
  String? _namaHari;

  void _hitung() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      setState(() {
        List<String> hari = [
          'Senin',
          'Selasa',
          'Rabu',
          'Kamis',
          'Jumat',
          'Sabtu',
          'Minggu',
        ];
        _namaHari = hari[_hari! - 1];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menu Penghitung Hari')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Masukkan angka (1-7)'),
                keyboardType: TextInputType.number,
                onSaved: (value) => _hari = int.tryParse(value!),
                validator: (value) {
                  if (value!.isEmpty) return 'Input tidak boleh kosong';
                  if (int.tryParse(value) == null ||
                      int.tryParse(value)! < 1 ||
                      int.tryParse(value)! > 7)
                    return 'Masukkan angka antara 1 hingga 7';
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: _hitung,
                child: Text('Hitung', style: TextStyle(fontSize: 18)),
              ),
              if (_namaHari != null) ...[
                Text(
                  'Hari ke-$_hari: $_namaHari',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
