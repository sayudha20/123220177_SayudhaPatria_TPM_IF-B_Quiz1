import 'package:flutter/material.dart';
import 'dart:math';

class MenuTrapesium extends StatefulWidget {
  @override
  _MenuTrapesiumState createState() => _MenuTrapesiumState();
}

class _MenuTrapesiumState extends State<MenuTrapesium> {
  final _formKey = GlobalKey<FormState>();
  double? _a, _b, _t;
  double? _luas, _keliling;

  void _hitung() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      setState(() {
        _luas = 0.5 * (_a! + _b!) * _t!;
        _keliling = _a! + _b! + 2 * sqrt(pow(_t!, 2) + pow((_b! - _a!) / 2, 2));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menu Trapesium')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Panjang sisi atas (a) [cm]',
                        ),
                        keyboardType: TextInputType.number,
                        onSaved: (value) => _a = double.tryParse(value!),
                        validator: (value) {
                          if (value!.isEmpty) return 'Input tidak boleh kosong';
                          return null;
                        },
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Panjang sisi bawah (b) [cm]',
                        ),
                        keyboardType: TextInputType.number,
                        onSaved: (value) => _b = double.tryParse(value!),
                        validator: (value) {
                          if (value!.isEmpty) return 'Input tidak boleh kosong';
                          return null;
                        },
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Tinggi (t) [cm]',
                        ),
                        keyboardType: TextInputType.number,
                        onSaved: (value) => _t = double.tryParse(value!),
                        validator: (value) {
                          if (value!.isEmpty) return 'Input tidak boleh kosong';
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: _hitung,
                child: Text('Hitung', style: TextStyle(fontSize: 18)),
              ),
              if (_luas != null && _keliling != null) ...[
                Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Text(
                          'Luas Trapesium: ${_luas!.toStringAsFixed(2)} cm²',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Keliling Trapesium: ${_keliling!.toStringAsFixed(2)} cm',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
