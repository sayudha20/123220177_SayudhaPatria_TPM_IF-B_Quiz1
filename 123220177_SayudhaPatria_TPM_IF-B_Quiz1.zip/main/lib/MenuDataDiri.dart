import 'package:flutter/material.dart';

class MenuDataDiri extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menu Data Diri')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('NIM: 123220177', style: TextStyle(fontSize: 18)),
            Text('Nama: Sayudha Patria', style: TextStyle(fontSize: 18)),
            Text('Kelas: IF-B', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
