import 'package:flutter/material.dart';

class MenuDataDiri extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menu Data Diri')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('NIM: 12345678', style: TextStyle(fontSize: 18)),
            Text('Nama: John Doe', style: TextStyle(fontSize: 18)),
            Text('Kelas: XII-A', style: TextStyle(fontSize: 18)),
            Text('Hobby: Membaca Buku', style: TextStyle(fontSize: 18)),
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage(
                'https://www.example.com/foto.jpg',
              ), // Ganti URL foto
            ),
          ],
        ),
      ),
    );
  }
}
